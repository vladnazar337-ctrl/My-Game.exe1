﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

namespace UltimateChaos
{
    class Program
    {
        static bool isActive = false;
        static string[] messagesToShow = {
            "hEllo My fRienD",
            "IM sTeaL yOu CompUtEr",
            "Meat Meat Meat",
            "LOL LOL LO LOOLOL"
        };
        static Random rand = new Random();

        // WinAPI для управления окнами и курсором
        [DllImport("kernel32.dll")]
        static extern IntPtr GetConsoleWindow();

        [DllImport("user32.dll")]
        static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

        [DllImport("user32.dll")]
        static extern bool SetCursorPos(int X, int Y);

        [DllImport("user32.dll")]
        static extern bool GetCursorPos(out POINT lpPoint);

        const uint SWP_NOSIZE = 0x0001;
        const uint SWP_NOZORDER = 0x0004;

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT
        {
            public int X;
            public int Y;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Здравствуй.");

            // Создаем временный файл с текстом "hello"
            string tempFilePath = Path.GetTempFileName() + ".txt";
            File.WriteAllText(tempFilePath, "hello");
            // Открываем блокнот
            Process.Start("notepad.exe", tempFilePath);

            Thread.Sleep(3000);
            Console.WriteLine("Хочешь запустить мою игру?");
            string answer = Console.ReadLine().ToLower();

            if (answer == "да" || answer == "yes" || answer == "lf")
            {
                isActive = true;

                // Запускаем хаос эффектов
                Task.Run(() => MoveWindowRandomly());
                Task.Run(() => ShakeAndResizeWindow());
                Task.Run(() => RandomChaosText());
                Task.Run(() => ChangeConsoleColors());
                Task.Run(() => MaximizeWindow());
                Task.Run(() => ShakeAndMoveCursor());
                Task.Run(() => InfiniteChaos());
                Task.Run(() => ShowErrors());
                Task.Run(() => CreateRandomMessages());
                Task.Run(() => RapidWindowSizeChanges());
                Task.Run(() => RandomSoundEffects());
                Task.Run(() => LeaveCursorTrail());
                Task.Run(() => OpenMessagesInNotepad());
                Task.Run(() => CreateRandomFilesAndFolders());
                Task.Run(() => ShuffleDesktopIcons());
                Task.Run(() => ChangeConsoleBackgroundColors()); // изменение цвета фона
                Task.Run(() => AnimateCursor()); // запуск анимации курсора

                Console.WriteLine("Нажми любую клавишу, чтобы остановить эффект.");
                Console.ReadKey();
                isActive = false;
            }
        }

        static void OpenMessagesInNotepad()
        {
            while (isActive)
            {
                string message = messagesToShow[rand.Next(messagesToShow.Length)];
                string messageFile = Path.GetTempFileName() + ".txt";
                File.WriteAllText(messageFile, message);
                Process.Start("notepad.exe", messageFile);
                Thread.Sleep(2000);
            }
        }

        static void ShowErrors()
        {
            string[] messages = {
                "I'm kill you PC!",
                "Your system is compromised!",
                "Hacker detected!",
                "System failure!",
                "Unauthorized access!",
                "Virus spreading...",
            };

            while (isActive)
            {
                string msg = messages[rand.Next(messages.Length)];
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"[ERROR]: {msg}");
                Thread.Sleep(500 + rand.Next(0, 1000));
            }
        }

        static void CreateRandomMessages()
        {
            string[] messages = {
                " SYSTEM ERROR ",
                " PLEASE RESTART ",
                " ERROR 0x0000 ",
                " SYSTEM CRASH ",
                " WARNING: MALWARE DETECTED ",
                " YOUR PC IS MINE ",
                " HACKED BY AI ",
                " KILL ALL PROCESS ",
            };
            string symbols = "!@#$%^&*()_+-=<>?:;\"'[]{}|\\0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

            while (isActive)
            {
                int length = rand.Next(10, 50);
                string line = "";
                for (int i = 0; i < length; i++)
                {
                    line += symbols[rand.Next(symbols.Length)];
                }
                Console.ForegroundColor = (ConsoleColor)rand.Next(0, 16);
                Console.WriteLine(messages[rand.Next(messages.Length)] + " " + line);
                Thread.Sleep(300 + rand.Next(0, 700));
            }
        }

        static void RapidWindowSizeChanges()
        {
            IntPtr hWnd = GetConsoleWindow();
            while (isActive)
            {
                try
                {
                    int width = rand.Next(10, Console.LargestWindowWidth);
                    int height = rand.Next(5, Console.LargestWindowHeight);
                    Console.SetWindowSize(width, height);
                    int x = rand.Next(0, Console.LargestWindowWidth);
                    int y = rand.Next(0, Console.LargestWindowHeight);
                    SetWindowPos(hWnd, IntPtr.Zero, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
                }
                catch { }
                Thread.Sleep(100);
            }
        }

        static void RandomSoundEffects()
        {
            int[] frequencies = { 262, 294, 330, 349, 392, 440, 494, 523, 587, 659, 698, 784, 880, 988, 1047, 1175, 1319, 1397, 1568, 1760, 1976 };
            int[] durations = { 50, 80, 100, 150, 200, 250, 300, 350, 400 };

            while (isActive)
            {
                int patternType = rand.Next(0, 3);
                switch (patternType)
                {
                    case 0:
                        for (int i = 0; i < rand.Next(3, 8); i++)
                        {
                            int freq = frequencies[rand.Next(frequencies.Length)];
                            int dur = durations[rand.Next(durations.Length)];
                            Console.Beep(freq, dur);
                            Thread.Sleep(rand.Next(20, 100));
                        }
                        break;
                    case 1:
                        Console.Beep(220, 600);
                        Thread.Sleep(100);
                        break;
                    case 2:
                        int notesCount = rand.Next(3, 6);
                        for (int i = 0; i < notesCount; i++)
                        {
                            int freq = frequencies[rand.Next(frequencies.Length)];
                            int dur = durations[rand.Next(durations.Length)];
                            Console.Beep(freq, dur);
                            Thread.Sleep(rand.Next(50, 150));
                        }
                        break;
                }
                Thread.Sleep(rand.Next(50, 200));
            }
        }

        static void MoveWindowRandomly()
        {
            IntPtr hWnd = GetConsoleWindow();
            while (isActive)
            {
                int screenWidth = Console.LargestWindowWidth * 10;
                int screenHeight = Console.LargestWindowHeight * 10;
                int x = rand.Next(0, screenWidth);
                int y = rand.Next(0, screenHeight);
                SetWindowPos(hWnd, IntPtr.Zero, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
                Thread.Sleep(100);
            }
        }

        static void ShakeAndResizeWindow()
        {
            IntPtr hWnd = GetConsoleWindow();
            while (isActive)
            {
                try
                {
                    int offsetX = rand.Next(-10, 11);
                    int offsetY = rand.Next(-10, 11);
                    int newWidth = Math.Max(10, Console.WindowWidth + rand.Next(-5, 6));
                    int newHeight = Math.Max(5, Console.WindowHeight + rand.Next(-3, 4));
                    int newLeft = Math.Max(0, Console.WindowLeft + offsetX);
                    int newTop = Math.Max(0, Console.WindowTop + offsetY);
                    Console.SetWindowSize(newWidth, newHeight);
                    Console.SetWindowPosition(newLeft, newTop);
                }
                catch { }
                Thread.Sleep(100);
            }
        }

        static void RandomChaosText()
        {
            string symbols = "!@#$%^&*()_+-=<>?:;\"'[]{}|\\0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            while (isActive)
            {
                int length = rand.Next(5, 30);
                string line = "";
                for (int i = 0; i < length; i++)
                {
                    line += symbols[rand.Next(symbols.Length)];
                }
                Console.WriteLine(line);
                Thread.Sleep(50);
            }
        }

        static void OpenThreatNotepad()
        {
            while (isActive)
            {
                string threatFilePath = Path.GetTempFileName() + ".txt";
                File.WriteAllText(threatFilePath, "ВАШ ПК В ПЕРЕДАЧЕ!\nЭто опасно для вас!");
                Process.Start("notepad.exe", threatFilePath);
                Thread.Sleep(700);
            }
        }

        static void CreateHelloFolders()
        {
            while (isActive)
            {
                try
                {
                    string folderName = "Hello)";
                    string folderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), folderName + "_" + DateTime.Now.ToString("HHmmssfff"));
                    Directory.CreateDirectory(folderPath);
                }
                catch { }
                Thread.Sleep(2000);
            }
        }

        static void ShuffleDesktopIcons()
        {
            while (isActive)
            {
                // Тут можно реализовать перемешивание иконок, если есть доступ
                Thread.Sleep(2000);
            }
        }

        static void LeaveCursorTrail()
        {
            while (isActive)
            {
                GetCursorPos(out POINT p);
                int x = p.X;
                int y = p.Y;
                // Можно оставить след или рисовать
                Thread.Sleep(50);
            }
        }

        static void ShakeAndMoveCursor()
        {
            while (isActive)
            {
                try
                {
                    int offsetX = rand.Next(-50, 51);
                    int offsetY = rand.Next(-20, 21);
                    int currentLeft = Console.CursorLeft;
                    int currentTop = Console.CursorTop;
                    int newLeft = Math.Max(0, Math.Min(Console.BufferWidth - 1, currentLeft + offsetX));
                    int newTop = Math.Max(0, Math.Min(Console.BufferHeight - 1, currentTop + offsetY));
                    Console.SetCursorPosition(newLeft, newTop);
                }
                catch { }
                Thread.Sleep(50);
            }
        }

        static void AnimateCursor()
        {
            // Эта функция будет постоянно перемещать курсор по всему экрану
            int width = Console.WindowWidth;
            int height = Console.WindowHeight;
            int x = 0;
            int y = 0;
            int deltaX = 1;
            int deltaY = 1;

            while (isActive)
            {
                try
                {
                    // Перемещать курсор по зигзагу или по всему экрану
                    SetCursorPos(x + Console.WindowLeft, y + Console.WindowTop);
                }
                catch { }

                // Обновляем координаты
                x += deltaX;
                y += deltaY;

                if (x >= width - 1 || x <= 0) deltaX = -deltaX;
                if (y >= height - 1 || y <= 0) deltaY = -deltaY;

                Thread.Sleep(20);
            }
        }

        static void ChangeConsoleColors()
        {
            while (isActive)
            {
                Console.ForegroundColor = (ConsoleColor)rand.Next(0, 16);
                Console.BackgroundColor = (ConsoleColor)rand.Next(0, 16);
                Thread.Sleep(300);
            }
        }

        static void MaximizeWindow()
        {
            try
            {
                while (isActive)
                {
                    Console.SetWindowSize(Console.LargestWindowWidth, Console.LargestWindowHeight);
                    Thread.Sleep(1000);
                }
            }
            catch { }
        }

        static void InfiniteChaos()
        {
            string symbols = "!@#$%^&*()_+-=<>?:;\"'[]{}|\\0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            while (isActive)
            {
                Console.ForegroundColor = (ConsoleColor)rand.Next(0, 16);
                string line = "";
                int length = rand.Next(30, 80);
                for (int i = 0; i < length; i++)
                {
                    line += symbols[rand.Next(symbols.Length)];
                }
                Console.WriteLine(line);
                Thread.Sleep(50);
            }
        }

        static void CreateRandomFilesAndFolders()
        {
            while (isActive)
            {
                try
                {
                    string folderName = "ChaosFolder_" + rand.Next(1000, 9999);
                    string folderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), folderName);
                    Directory.CreateDirectory(folderPath);
                }
                catch { }

                try
                {
                    string fileName = "ChaosFile_" + rand.Next(1000, 9999) + ".txt";
                    string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), fileName);
                    File.WriteAllText(filePath, "Chaos generated file " + DateTime.Now.ToString());
                }
                catch { }

                Thread.Sleep(3000);
            }
        }

        static void ChangeConsoleBackgroundColors()
        {
            ConsoleColor[] colorsSequence = {
                ConsoleColor.Yellow,
                ConsoleColor.Magenta,
                ConsoleColor.DarkMagenta,
                ConsoleColor.DarkBlue,
                ConsoleColor.Blue,
                ConsoleColor.DarkCyan,
                ConsoleColor.Cyan,
                ConsoleColor.Gray
            };
            int index = 0;
            while (isActive)
            {
                Console.BackgroundColor = colorsSequence[index];
                Console.Clear();
                index = (index + 1) % colorsSequence.Length;
                Thread.Sleep(100);
            }
        }
    }
}